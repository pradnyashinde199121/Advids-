import { Component, OnInit } from '@angular/core';
import{User} from'../user';
@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
   userModel= new User( 'first Name','lastName','abc@cde.com')
   public minDate: Date;
   public minDate1: Date;
   date : any;
  constructor() {
    const currentYear = new Date().getFullYear();
    this.minDate = new Date();
    this.minDate1 =new Date();
   }
  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;

    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }
  ngOnInit() {
  }
  changedate(){
    this.minDate1 = this.date; 
  }

}
