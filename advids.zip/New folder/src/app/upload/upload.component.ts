import { Component, OnInit, ViewChild, ElementRef  } from '@angular/core';
import{UploadService} from'../upload.service';
import { HttpEventType, HttpErrorResponse } from '@angular/common/http';
import { of } from 'rxjs';  
import { catchError, map } from 'rxjs/operators'; 

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {
  fileToUpload: File = null;
  @ViewChild("fileUpload", {static: false}) fileUpload: ElementRef;
  files  = []; 
  public fileData = []; 
  public array=[ 'image/png','image/jpeg'];
  isUploaded: boolean = false;

  constructor(public uploadService:UploadService) { }

  ngOnInit() {
    
  }
  uploadFile(file) {  //step3
    const formData = new FormData();  
    formData.append('file', file.data);  
    file.inProgress = true;  
    this.uploadService.upload(formData).pipe(                //loader start
      map(event => {  
        switch (event.type) {  
          case HttpEventType.UploadProgress:  
            file.progress = Math.round(event.loaded * 100 / event.total);  
            break;  
          case HttpEventType.Response:  
            return event;  
        }  
      }),  
      catchError((error: HttpErrorResponse) => {  
        file.inProgress = false;  
        return of(`${file.data.name} upload failed.`);        //Loader end
      })).subscribe((event: any) => {                         //data from service subscribed and stored in filedata
        if (typeof (event) === 'object') {  
          console.log(event.body);
          event.body.type = file.data.type;
          event.body.name = file.data.name;
          this.fileData.push(event.body);                     //final data stored in fileData
        }  
      });  
  }
  private uploadFiles() {  //step2
    this.fileUpload.nativeElement.value = '';  
    this.files.forEach(file => {  
      this.uploadFile(file);  
    });  
    this.isUploaded = true;
}
onClick() {  // step1
  this.files  = []; //empty the array for new request
  const fileUpload = this.fileUpload.nativeElement;
  fileUpload.onchange = () => {  
  for (let index = 0; index < fileUpload.files.length; index++)  
  {  
   const file = fileUpload.files[index];  
   this.files.push({ data: file, inProgress: false, progress: 0});  
  }  
    this.uploadFiles();  
  };  
  fileUpload.click();  
}

}
