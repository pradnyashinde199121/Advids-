import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PeginationComponent } from './pegination.component';

describe('PeginationComponent', () => {
  let component: PeginationComponent;
  let fixture: ComponentFixture<PeginationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PeginationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PeginationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
