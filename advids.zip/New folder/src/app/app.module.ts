import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,ReactiveFormsModule}   from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormComponent } from './form/form.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatDatepickerModule,MatNativeDateModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatSortModule, MatTableModule} from '@angular/material';
import { FetchDataComponent } from './fetch-data/fetch-data.component';
import{MyserviceService} from'./myservice.service';
import{UploadService} from'./upload.service';
import { HttpClientModule } from '@angular/common/http';
import { UploadComponent } from './upload/upload.component';
import { MatToolbarModule,  
  MatIconModule,  
  MatCardModule,  
  MatButtonModule,  
  MatProgressBarModule,MatPaginatorModule, MatCheckboxModule,} from '@angular/material';
import { PeginationComponent } from './pegination/pegination.component';
import{PagerService} from'./pager.service';
import { Pegination1Component } from './pegination1/pegination1.component';
import { ExtraComponent } from './extra/extra.component';

@NgModule({
  declarations: [
    AppComponent,
    FormComponent,
    FetchDataComponent,
    UploadComponent,
    PeginationComponent,
    Pegination1Component,
    ExtraComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    HttpClientModule,
    MatToolbarModule,  
    MatIconModule,  
    MatCardModule,  
    MatButtonModule,  
    MatProgressBarModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatSortModule,
    MatTableModule,
    MatCheckboxModule,
  ],
  providers: [MyserviceService,UploadService,PagerService,],
  bootstrap: [AppComponent]
})
export class AppModule { 
  MatInputModule;
  MatFormFieldModule;
}
