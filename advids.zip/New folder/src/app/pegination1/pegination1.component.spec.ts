import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Pegination1Component } from './pegination1.component';

describe('Pegination1Component', () => {
  let component: Pegination1Component;
  let fixture: ComponentFixture<Pegination1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Pegination1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Pegination1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
