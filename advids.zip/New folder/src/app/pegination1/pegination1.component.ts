import { Component, OnInit, ViewChild ,ChangeDetectorRef,OnDestroy } from '@angular/core';
import { MatTableDataSource, MatSort,MatPaginator } from '@angular/material';
import { DataSource } from '@angular/cdk/table';
import {Sort} from '@angular/material/sort';
import { Observable } from 'rxjs';
export interface PeriodicElement {
  name: string;
  position: number;
  price: number;
  Model: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: 'Samsung', price: 12999, Model: 'Samsung Galaxy M21	'},
  {position: 2, name: 'Apple', price: 99900, Model: 'iPhone 11 Pro'},
  {position: 3, name: 'Huawei', price: 14000, Model: 'Huawei Y9 Prime 2019'},
  {position: 4, name: 'Xiaomi', price: 9.0122, Model: 'Redmi Note 9 Pro'},
  {position: 5, name: ' Oppo', price: 15000, Model: 'Oppo A31'},
  {position: 6, name: 'LG', price: 7000, Model: 'LG W10'},
  {position: 7, name: 'Motorola', price: 14000, Model: 'Ngkjhsl'},
  {position: 8, name: 'Mobicel', price: 15094, Model: 'Ogxvjhk'},
  {position: 9, name: 'Lenovo ', price: 18984, Model: 'Fgu2iob'},
  {position: 10, name: 'Nokia', price: 20797, Model: 'Nevjhl'},
  {position: 1, name: 'Samsung', price: 73000, Model: 'Samsung Galaxy S20+	'},
  {position: 2, name: 'Apple', price: 109900, Model: 'iPhone 11 Pro Max	'},
  {position: 3, name: 'Huawei', price: 17290, Model: 'Huawei P30 Lite'},
  {position: 4, name: 'Xiaomi', price: 52990, Model: 'Redmi 8A'},
  {position: 5, name: ' Oppo', price: 20000, Model: 'Oppo F15'},
  {position: 6, name: 'LG', price: 60000, Model: 'LG W3'},
  {position: 7, name: 'Motorola', price: 14000, Model: 'LG W15'},
  {position: 8, name: 'Mobicel', price: 15094, Model: 'Ooooooo'},
  {position: 9, name: 'Lenovo ', price: 18984, Model: 'Fjkkgui'},
  {position: 10, name: 'Nokia', price: 20797, Model: 'Neguhio'},
  {position: 1, name: 'Samsung', price: 92000, Model: 'Samsung Galaxy S20 Ultra'},
  {position: 2, name: 'Apple', price: 64900, Model: 'iPhone 11 '},
  {position: 3, name: 'Huawei', price: 52990, Model: 'Huawei P30 Pro'},
  {position: 4, name: 'Xiaomi', price: 40000, Model: 'Xiaomi Mi 10	'},
  {position: 5, name: ' Oppo', price: 18000, Model: 'Oppo A5'},
  {position: 6, name: 'LG', price: 12107, Model: 'Cfjhhlk'},
  {position: 7, name: 'Motorola', price: 14.0067, Model: 'Ngdyhg'},
  {position: 8, name: 'Mobicel', price: 15994, Model: 'Ocdyg'},
  {position: 9, name: 'Lenovo ', price: 18984, Model: 'Fdujyui'},
  {position: 10, name: 'Nokia', price: 20797, Model: 'Nedyt'}
];
export interface Level {
    name: string;
    active: boolean;
}

@Component({
  selector: 'app-pegination1',
  templateUrl: './pegination1.component.html',
  styleUrls: ['./pegination1.component.css']
})

export class Pegination1Component implements OnInit {
  [x: string]: any;
  samcheck:boolean = false;
  displayedColumns: string[] = ['position', 'name', 'price', 'Model'];
  
  @ViewChild(MatPaginator,{static: true}) paginator: MatPaginator;
  obs: Observable<any>;
  dataSource: MatTableDataSource<any> = new MatTableDataSource<any>(ELEMENT_DATA);
  levelsToShow: Level[] = [
    { name: 'Samsung', active: false },
    { name: 'Apple', active: false },
    { name: 'Oppo', active: false },
    { name: 'Xiaomi', active: false }
  ];
  filteredValues = {
    name: ''
  };
  globalFilter = '';

  
  constructor(  private changeDetectorRef: ChangeDetectorRef) { }

  ngOnInit() {
    
    this.dataSource =  new MatTableDataSource<any>(ELEMENT_DATA);    
    this.changeDetectorRef.detectChanges();
    this.dataSource.paginator = this.paginator;
    this.dataSource.filterPredicate = this.customFilterPredicate();
    this.obs = this.dataSource.connect();    
  }
    
  customFilterPredicate() {
    const myFilterPredicate = (data: PeriodicElement, filter: string): boolean => {
      var globalMatch = !this.globalFilter;

      if (this.globalFilter) {
        // search all text fields
        globalMatch = data.name.toString().trim().toLowerCase().indexOf(this.globalFilter.toLowerCase()) !== -1;
      }

      if (!globalMatch) {
        return;
      }

      let searchString = JSON.parse(filter);
      return data.name.toString().trim().toLowerCase().indexOf(searchString.name.toLowerCase()) !== -1 &&
        (this.levelsToShow.filter(level => !level.active).length === this.levelsToShow.length ||
          this.levelsToShow.filter(level => level.active).some(level => level.name.trim().toLowerCase() === data.name.trim().toLowerCase()));
    }
    return myFilterPredicate;
  }
  updateFilter() {
    this.dataSource.filter = JSON.stringify(this.filteredValues);
  }
  applyFilter(filterValue: string) {

    this.dataSource.filter = filterValue.trim().toLowerCase();
    
     }
   
     changed(evt) {
       if(evt.target.checked){
         if(this.dataSource.filter != ''){
           const filtertext  = this.filter(this.dataSource.filter,evt.target.value.trim().toLowerCase())
           this.dataSource.filterPredicate = (data: PeriodicElement, filtertext) => {
             return filtertext.split(',').every((item: any) => data.name.indexOf(item) !== -1);
           };
         }
         else{
           this.dataSource.filter = evt.target.value.trim().toLowerCase();
         }
        
        
       }
       else{
         this.dataSource.filter ='';
       }
      
     }
     filter(filter : string,value : string){
   if(filter != ''){
     return filter + "," +value;
   }
     }
  ngOnDestroy() {
    if (this.dataSource) { 
      this.dataSource.disconnect(); 
    }
  }
  
}
