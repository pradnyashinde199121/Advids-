import { Component, OnInit, ViewChild ,ChangeDetectorRef,OnDestroy } from '@angular/core';
import { MatTableDataSource, MatSort,MatPaginator } from '@angular/material';
import { DataSource } from '@angular/cdk/table';
import {Sort} from '@angular/material/sort';
import { Options, LabelType } from 'ng5-slider';
import { Observable } from 'rxjs';
export interface MobileCompanies {
  id:number
  name: string;
  position: number;
  price: number;
  Model: string;
}

const MobileData: MobileCompanies[] = [
  {id:1, position: 1, name: 'Samsung', price: 12999, Model: 'Samsung Galaxy M21	'},
  {id:2,position: 2, name: 'Apple', price: 99900, Model: 'iPhone 11 Pro'},
  {id:3,position: 3, name: 'Huawei', price: 14000, Model: 'Huawei Y9 Prime 2019'},
  {id:4,position: 4, name: 'Xiaomi', price: 9.0122, Model: 'Redmi Note 9 Pro'},
  {id:5,position: 5, name: ' Oppo', price: 15000, Model: 'Oppo A31'},
  {id:6,position: 6, name: 'LG', price: 7000, Model: 'LG W10'},
  {id:7,position: 7, name: 'Motorola', price: 14000, Model: 'Ngkjhsl'},
  {id:8,position: 8, name: 'Mobicel', price: 15094, Model: 'Ogxvjhk'},
  {id:9,position: 9, name: 'Lenovo ', price: 18984, Model: 'Fgu2iob'},
  {id:10,position: 10, name: 'Nokia', price: 20797, Model: 'Nevjhl'},
  {id:11,position: 1, name: 'Samsung', price: 73000, Model: 'Samsung Galaxy S20+	'},
  {id:12,position: 2, name: 'Apple', price: 109900, Model: 'iPhone 11 Pro Max	'},
  {id:13,position: 3, name: 'Huawei', price: 17290, Model: 'Huawei P30 Lite'},
  {id:14,position: 4, name: 'Xiaomi', price: 52990, Model: 'Redmi 8A'},
  {id:15,position: 5, name: ' Oppo', price: 20000, Model: 'Oppo F15'},
  {id:16,position: 6, name: 'LG', price: 60000, Model: 'LG W3'},
  {id:17,position: 7, name: 'Motorola', price: 14000, Model: 'LG W15'},
  {id:18,position: 8, name: 'Mobicel', price: 15094, Model: 'Ooooooo'},
  {id:19,position: 9, name: 'Lenovo ', price: 18984, Model: 'Fjkkgui'},
  {id:20,position: 10, name: 'Nokia', price: 20797, Model: 'Neguhio'},
  {id:21,position: 1, name: 'Samsung', price: 92000, Model: 'Samsung Galaxy S20 Ultra'},
  {id:22,position: 2, name: 'Apple', price: 64900, Model: 'iPhone 11 '},
  {id:23,position: 3, name: 'Huawei', price: 52990, Model: 'Huawei P30 Pro'},
  {id:24,position: 4, name: 'Xiaomi', price: 40000, Model: 'Xiaomi Mi 10	'},
  {id:25,position: 5, name: ' Oppo', price: 18000, Model: 'Oppo A5'},
  {id:26,position: 6, name: 'LG', price: 12107, Model: 'Cfjhhlk'},
  {id:27,position: 7, name: 'Motorola', price: 14.0067, Model: 'Ngdyhg'},
  {id:28,position: 8, name: 'Mobicel', price: 15994, Model: 'Ocdyg'},
  {id:29,position: 9, name: 'Lenovo ', price: 18984, Model: 'Fdujyui'},
  {id:30,position: 10, name: 'Nokia', price: 20797, Model: 'Nedyt'}
];
export interface Level {
    name: string;
    active: boolean;
}

@Component({
  selector: 'app-pegination1',
  templateUrl: './pegination1.component.html',
  styleUrls: ['./pegination1.component.css']
})

export class Pegination1Component implements OnInit {
  
  showTicks = false;
  thumbLabel = false;
  value = 0;
  tickInterval = 500;
  autoTicks: any;
  flag:boolean=true;
  cartData:any=[];
  totalvalue=0;
  minValue: number = 1000;
  maxValue: number = 100000;
  options: Options = {
    floor: 0,
    ceil: 100000,
    translate: (value: number, label: LabelType): string => {
      switch (label) {
        case LabelType.Low:
          return '<b>Min price:' + value;
        case LabelType.High:
          return '<b>Max price:' + value;
        default:
          return '$' + value;
      }
    }
  };
  getSliderTickInterval(): number | 'auto' {
    if (this.showTicks) {
      return this.autoTicks ? 'auto' : this.tickInterval;
    }

    return 0;
  }

  @ViewChild(MatPaginator,{static: true}) paginator: MatPaginator;
  obs: Observable<any>;
  dataSource: MatTableDataSource<any> = new MatTableDataSource<any>(MobileData);
  levelsToShow: Level[] = [
    { name: 'Samsung', active: false },
    { name: 'Apple', active: false },
    { name: 'Oppo', active: false },
    { name: 'Xiaomi', active: false }
  ];
  filteredValues = {
    name: '',
    price: ''
  };

  constructor(  private changeDetectorRef: ChangeDetectorRef) { }

  ngOnInit() {
    this.dataSource =  new MatTableDataSource<any>(MobileData);    
    this.changeDetectorRef.detectChanges();
    this.dataSource.paginator = this.paginator;
    this.dataSource.filterPredicate = this.customFilterPredicate(); //filter for multiple value
    this.obs = this.dataSource.connect();    
  }  
  customFilterPredicate() {
    const myFilterPredicate = (data: MobileCompanies, filter: string): boolean => {
      let searchString = JSON.parse(filter);
      return data.name.toString().trim().toLowerCase().indexOf(searchString.name.toLowerCase()) !== -1 && data. price >= this.minValue && data. price <= this.maxValue &&
       (this.levelsToShow.filter(level => !level.active).length === this.levelsToShow.length ||
          this.levelsToShow.filter(level => level.active).some(level => level.name.trim().toLowerCase() === data.name.trim().toLowerCase()) && data. price >= this.minValue && data. price <= this.maxValue);
          
    }
    return myFilterPredicate;
  }
  updateFilter() {
    this.dataSource.filter = JSON.stringify(this.filteredValues);
  }

  changeFilter(event){
    if(event.target.value === "price"){
      this.flag = true;
    }
   else {
      this.flag = false;
    }

  }
  sendData(element){
    this.cartData.push(element);
 this.totalvalue=element.price+this.totalvalue; //total price count after add
  }
  updateTotalPrice(element) {
     this.totalvalue=this.totalvalue- element.price;
  }
  ngOnDestroy() {
    if (this.dataSource) { 
      this.dataSource.disconnect(); 
    }
  }
  
}