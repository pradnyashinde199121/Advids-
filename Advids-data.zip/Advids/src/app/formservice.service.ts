import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FormserviceService {
  Country:any=[{'id':1,'name':'INDIA'},{'id':2,'name':'USA'},{'id':3,'name':'JHGKJh'}]
  State:any=[{'id':1,'name':'Maharashtra',countryid:'1'},
  {'id':2,'name':'AP',countryid:'1'},
  {'id':3,'name':'MP',countryid:'1'},
  {'id':1,'name':'aaaa',countryid:'2'},
  {'id':2,'name':'bbbbb',countryid:'2'},
  {'id':3,'name':'ccccc',countryid:'2'},
  {'id':1,'name':'xxxxx',countryid:'3'},
  {'id':2,'name':'yyyyy',countryid:'3'},
  {'id':3,'name':'zzzz',countryid:'3'}
];
City:any=[ {'id':1,'name':'pune',countryid:'1' ,stateid:'1'},
{'id':2,'name':'mpcity',countryid:'1',stateid:'1'},
{'id':3,'name':'APcity',countryid:'1',stateid:'1'}];
  getCountries() {
    return this.Country;
  }
  
  getStates() {
   return this.State;
  }
  getCities(){
    return this.City;
  }
  constructor() { }
}
