import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,ReactiveFormsModule}   from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormComponent } from './form/form.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatDatepickerModule,MatNativeDateModule, MatFormFieldModule, MatInputModule, MatSelectModule, MatSortModule, MatTableModule, MatSliderModule} from '@angular/material';
import { FetchDataComponent } from './fetch-data/fetch-data.component';
import{MyserviceService} from'./myservice.service';
import{UploadService} from'./upload.service';
import { HttpClientModule } from '@angular/common/http';
import { UploadComponent } from './upload/upload.component';
import { MatToolbarModule,  
  MatIconModule,  
  MatCardModule,  
  MatButtonModule,  
  MatProgressBarModule,
  MatPaginatorModule,
   MatCheckboxModule,} from '@angular/material';
import { PeginationComponent } from './pegination/pegination.component';
import{PagerService} from'./pager.service';
import { Pegination1Component } from './pegination1/pegination1.component';
import { ExtraComponent } from './extra/extra.component';
import { Ng5SliderModule } from 'ng5-slider';
import { ChildComponent } from './child/child.component';
import{FormserviceService} from'./formservice.service';
import { CalenderComponent } from './calender/calender.component';
@NgModule({
  declarations: [
    AppComponent,
    FormComponent,
    FetchDataComponent,
    UploadComponent,
    PeginationComponent,
    Pegination1Component,
    ExtraComponent,
    ChildComponent,
    CalenderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    HttpClientModule,
    MatToolbarModule,  
    MatIconModule,  
    MatCardModule,  
    MatButtonModule,  
    MatProgressBarModule,
    MatPaginatorModule,
    MatFormFieldModule,
    MatInputModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatSortModule,
    MatTableModule,
    MatCheckboxModule,
    MatSliderModule,
    Ng5SliderModule,
  ],
  providers: [MyserviceService,UploadService,PagerService,FormserviceService,],
  bootstrap: [AppComponent]
})
export class AppModule { 
  MatInputModule;
  MatFormFieldModule;
}
