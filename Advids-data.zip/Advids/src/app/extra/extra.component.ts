import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatTable } from '@angular/material';
import { FormControl } from '@angular/forms';
import { Options, LabelType } from 'ng5-slider';

export interface PeriodicElement {
  name: string;
  level: number;
  weight: number;
  symbol: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  { level: 1, name: 'Samsung', weight: 1.0079, symbol: 'H' },
  { level: 2, name: 'Apple', weight: 4.0026, symbol: 'He' },
  { level: 3, name: 'oppo', weight: 6.941, symbol: 'Li' },
  { level: 3, name: 'oppo', weight: 9.0122, symbol: 'Be' },
  { level: 3, name: 'oppo', weight: 10.811, symbol: 'B' },
  { level: 2, name: 'Apple', weight: 12.0107, symbol: 'C' },
  { level: 1, name: 'Samsung', weight: 14.0067, symbol: 'N' },
  { level: 1, name: 'Samsung', weight: 15.9994, symbol: 'O' },
  { level: 2, name: 'Apple', weight: 18.9984, symbol: 'F' },
  { level: 2, name: 'Apple', weight: 20.1797, symbol: 'Ne' },
];


export interface Level {
  active: boolean;
  name: string;
  level: number;
}
@Component({
  selector: 'app-extra',
  templateUrl: './extra.component.html',
  styleUrls: ['./extra.component.css']
})
export class ExtraComponent implements OnInit {
  max = 100000;
  min = 0;
  showTicks = false;
  step = 500;
  thumbLabel = false;
  value = 0;
  tickInterval = 1;
  autoTicks: any;
  
  minValue: number = 1;
  maxValue: number = 20;
  options: Options = {
    floor: 0,
    ceil: 20,
    translate: (value: number, label: LabelType): string => {
      switch (label) {
        case LabelType.Low:
          return '<b>Min price:' + value;
        case LabelType.High:
          return '<b>Max price:' + value;
        default:
          return '$' + value;
      }
    }
  };
  getSliderTickInterval(): number | 'auto' {
    if (this.showTicks) {
      return this.autoTicks ? 'auto' : this.tickInterval;
    }

    return 0;
  }

  displayedColumns: string[] = ['level', 'name', 'weight', 'symbol'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);

  levelsToShow: Level[] = [
    { level: 1, active: false, name: 'Samsung' },
    { level: 2, active: false, name: 'Apple' },
    { level: 3, active: false, name: 'Oppo' },
  ];

  levelFilter = new FormControl();
  nameFilter = new FormControl();
  globalFilter = '';

  filteredValues = {
    level: '', 
    name: '', 
    weight: '',
    symbol: ''
  };

  ngOnInit() {
    this.nameFilter.valueChanges.subscribe((nameFilterValue) => {
      this.filteredValues['name'] = nameFilterValue;
      this.dataSource.filter = JSON.stringify(this.filteredValues);
    });

    this.dataSource.filterPredicate = this.customFilterPredicate();
  }

  customFilterPredicate() {
    const myFilterPredicate = (data: PeriodicElement, filter: string): boolean => {

      let searchString = JSON.parse(filter);
      return data.name.toString().trim().toLowerCase().indexOf(searchString.name.toLowerCase()) !== -1 && data.weight >= this.minValue && data.weight <= this.maxValue &&
        (this.levelsToShow.filter(level => !level.active).length === this.levelsToShow.length  ||
          this.levelsToShow.filter(level => level.active).some(level => level.level === data.level && data.weight >= this.minValue && data.weight <= this.maxValue));
          
    }
    return myFilterPredicate;
  }

   updateFilter() {
    this.dataSource.filter = JSON.stringify(this.filteredValues);
  }
}