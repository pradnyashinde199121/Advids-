import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FormComponent } from './form/form.component';
import { FetchDataComponent } from './fetch-data/fetch-data.component';
import { UploadComponent } from './upload/upload.component';
import { PeginationComponent } from './pegination/pegination.component';
import { Pegination1Component } from './pegination1/pegination1.component';
import { ExtraComponent } from './extra/extra.component';
import { ChildComponent } from './child/child.component';

const routes: Routes = [{path:'form', component:FormComponent},
 {path:'fetch-data', component:FetchDataComponent}, 
 {path:'upload', component:UploadComponent},
 {path:'pegination', component:PeginationComponent},
 {path:'pegination1', component:Pegination1Component},
 {path:'extra', component:ExtraComponent},
 {path:'child', component:ChildComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
