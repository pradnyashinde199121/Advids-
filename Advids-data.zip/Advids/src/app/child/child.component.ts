import { Component, OnInit,Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
flag:boolean;

  constructor() { }
@Input() reciveData:any =[];
@Input() TotalValue1:any=0;
@Output() removeEvent = new EventEmitter<any>();
  ngOnInit() {
  
  }
  
  changepara(){
    if(!this.flag){
      this.flag = true;
    }   
    else{
      this.flag = false;
    }
  }
  RemoveData(element){
    this.reciveData.pop(element);
   // this.TotalValue1=this.TotalValue1-element.price; //total price count
    this.removeEvent.emit(element);
  }

  
}
