import { Component, OnInit } from '@angular/core';
import{MyserviceService} from'../myservice.service';

@Component({
  selector: 'app-fetch-data',
  templateUrl: './fetch-data.component.html',
  styleUrls: ['./fetch-data.component.css']
})
export class FetchDataComponent implements OnInit {
 public data:[];
 load=true;
  constructor(public myservice:MyserviceService) { }

  ngOnInit() {
    this.myservice.getAlbum().subscribe(res=> {
      this.data=res;
      this.load=false;})
  
  }


}
