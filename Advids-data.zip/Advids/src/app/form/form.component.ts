import { Component, OnInit } from '@angular/core';
import{FormserviceService} from '../formservice.service';
import{User} from'../user';
@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})

export class FormComponent implements OnInit {
   userModel= new User( 'first Name','lastName','abc@cde.com')
   public minDate: Date;
   public minDate1: Date;
   date : any;
   countries:any;
  states: any;
  cities: any;
  countrycode=[91,92,202,67,87];
  //selectedCountry:any={'name':'--Select--','id':'0'};
  constructor(private selectService:FormserviceService) {
    const currentYear = new Date().getFullYear();
    this.minDate = new Date();
    this.minDate1 =new Date();
   }
  keyPress(event: any) {
    const pattern = /[0-9\+\-\ ]/;

    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.test(inputChar)) {
      event.preventDefault();
    }
  }
  password(event: any) {
    const pattern = "(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}";

    let inputChar = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !pattern.indexOf(inputChar)) {
      event.preventDefault();
    }
  }
  ngOnInit() {
    this.countries = this.selectService.getCountries();
    //this.onSelect(this.selectedCountry.id);
  }
  changedate(){
    this.minDate1 = this.date; 
  }
  //dependant dropdown for country state
  onSelect(countryid) {
    const states = this.selectService.getStates();
    this.states=states.filter((item) => item.countryid === countryid);

  }
  stateChange(stateid){
    const cities = this.selectService.getCities();
    this.cities=cities.filter((item) => item.stateid === stateid);
  }

}
