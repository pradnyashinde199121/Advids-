import { Component, OnInit,ViewChild, ChangeDetectorRef,OnDestroy } from '@angular/core';
import{MyserviceService} from '../myservice.service';
import { MatTableDataSource, MatPaginator,MatSort } from '@angular/material';
import { Observable } from 'rxjs';
export interface Card {
  title: string;
  url: string;
}

@Component({
  selector: 'app-pegination',
  templateUrl: './pegination.component.html',
  styleUrls: ['./pegination.component.css']
})
export class PeginationComponent implements OnInit, OnDestroy {
  public data:[];
  //dataSource= new MatTableDataSource();
 // @ViewChild(MatSort,{static:true}) sort: MatSort;
  @ViewChild(MatPaginator,{static: true}) paginator: MatPaginator;
  obs: Observable<any>;
  dataSource: MatTableDataSource<any> = new MatTableDataSource<any>();

  constructor(private myservice:MyserviceService, private changeDetectorRef: ChangeDetectorRef) {
  }

  ngOnInit() {
    this.myservice.getAlbum().subscribe(res=> {
    this.data=res;
    this.dataSource =  new MatTableDataSource<any>(this.data);    
    this.changeDetectorRef.detectChanges();
    this.dataSource.paginator = this.paginator;
    this.obs = this.dataSource.connect(); 
    });
       
  }
  ngOnDestroy() {
    if (this.dataSource) { 
      this.dataSource.disconnect(); 
    }
  }
  

 
}